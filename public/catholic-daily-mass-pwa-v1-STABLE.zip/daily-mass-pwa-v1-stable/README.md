# Catholic Daily Mass — PWA

A digital missal: today's full Catholic Mass readings, readable and listenable,
installable on any phone. Built on your reference stack — React/Vite + Vercel
PWA, Firebase-ready for push notifications.

## Adding a real photo (hero image + listening backdrop)

The app looks for two optional photo files in `public/` and falls back to a
drawn illustration automatically if they're missing — so nothing breaks
either way.

1. Pick a photo — good, freely-licensed picks (Unsplash License: free for
   commercial use, no attribution legally required):
   - https://unsplash.com/photos/golden-monstrance-with-sunburst-rays-oNcbnf3bNys
   - https://unsplash.com/photos/golden-monstrance-with-cross-BV1OPtEvFpE
   - https://unsplash.com/photos/golden-monstrance-with-crucifix-in-background--14VsipJWLo
   - https://unsplash.com/photos/our-lord-in-the-monstrance-at-a-lifeteen-conference-OrovnGeyG-A
2. Click through to the photo page and use Unsplash's own **Download** button
   (this respects their license flow properly).
3. Save it into the project as:
   - `public/hero-photo.jpg` — the small circular image at the top of the app
   - `public/listening-photo.jpg` — the large backdrop shown while ▶ Listen
     is playing (a square-ish or portrait crop works best; it's shown inside
     a circle with a warm garnet tint over it for legibility)
4. `npm run build` again — no code changes needed.

You can use the same photo for both, or two different ones.

**Readings source:** the official Universalis JSONP webmaster service, which
permits displaying their content on web pages. The app fulfils their two
conditions automatically: the copyright notice from each day's data is shown in
the footer, and a visible link to Universalis is always present.

## Features (v1)

- **Today's readings** — feast of the day, First Reading, Psalm, Second
  Reading (Sundays), Gospel Acclamation, Gospel, in a missal-style layout
  with an illuminated initial on the Gospel
- **Listen** — on-device text-to-speech reads the readings aloud at a
  measured pace, highlighting the section being read (free, private, no
  audio hosting needed)
- **Archive** — browse any past or future date with the ‹ › arrows
- **Offline** — the last 14 days you've opened are cached; the app shell
  works fully offline
- **Installable** — Add to Home Screen on Android and iOS
- **Accessible** — large serif type, high contrast, big touch targets,
  keyboard focus, reduced-motion support

## Run and deploy (your usual flow)

```bash
npm install
npm run dev        # local preview
npm run build      # production build in dist/
```

1. Create GitHub repo (e.g. `siliconroute-ctrl/catholic-daily-mass`), push.
2. Vercel → New Project → import the repo. Framework: Vite. Deploy.
3. `vercel.json` SPA rewrites are already in place.

## WordPress branch-out (when ready)

Two options, simplest first:

1. **Iframe embed** — on any WP page:
   `<iframe src="https://YOUR-APP.vercel.app" style="width:100%;height:90vh;border:none"></iframe>`
2. **Native embed** — copy the JSONP pattern from `src/lib/universalis.js`
   into a small WP page template; same data, styled by your theme.

## Facebook page tie-in

The Facebook bot we built earlier can now link to **your app** instead of
Universalis — your page drives installs of your own app. One-line change in
`post-daily-mass.js`: set the link to your Vercel URL.

## Phase 2 — Push notifications (the Jeremiah pattern)

Everything is pre-wired but dormant:

- `src/pushConfig.js` holds the VAPID key and Firebase config (isolated, per
  your Jeremiah lesson). While empty, all notification UI stays hidden.
- When ready: create a Firebase project, paste config + VAPID key, add
  `firebase-messaging-sw.js`, and reuse your 07:00 SAST send mechanism.
  Suggested topic name: `daily-readings`.

## Phase 3 — Google Play

Your Play Console is approved. Wrap with Capacitor (as planned for Soccer
Warriors) or use Bubblewrap/TWA since this is a fully compliant PWA — TWA is
lighter and updates instantly with each Vercel deploy.

## Notes

- Default calendar is the general Universalis one (Jerusalem Bible — used at
  Mass in most of the English-speaking world, including Africa). A regional
  calendar (e.g. a South African or Nigerian one) can be added later by
  passing a calendar code to `fetchReadings` — codes are on universalis.com.
- If Universalis ever changes their data field names, the app renders
  whatever `Mass_*` sections it receives rather than going blank
  (see `normaliseReadings`).
