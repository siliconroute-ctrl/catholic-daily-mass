import { useCallback, useEffect, useRef, useState } from "react";
import {
  fetchReadings,
  normaliseReadings,
  displayDate,
} from "./lib/universalis.js";
import * as tts from "./lib/tts.js";
import { liturgicalYearLetter, weekdayCycleNumeral } from "./lib/liturgicalYear.js";
import { loadSavedRegion, saveRegion } from "./lib/regions.js";
import EntranceScreen from "./components/EntranceScreen.jsx";

const DAY_MS = 24 * 60 * 60 * 1000;

function sameDay(a, b) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export default function App() {
  const [entered, setEntered] = useState(false);
  const [date, setDate] = useState(() => new Date());
  const [region, setRegion] = useState(() => loadSavedRegion());
  const [state, setState] = useState({ status: "loading" });
  const [reading, setReading] = useState(null);
  const [playState, setPlayState] = useState("idle");
  const topRef = useRef(null);

  const load = useCallback((d, cal) => {
    setState({ status: "loading" });
    fetchReadings(d, cal)
      .then((raw) => {
        setState({ status: "ready", data: normaliseReadings(raw) });
        if (topRef.current) topRef.current.scrollIntoView({ block: "start" });
      })
      .catch((err) => setState({ status: "error", message: err.message }));
  }, []);

  // Fetch quietly in the background even while on the entrance screen, so
  // the readings are already there the moment the person steps in.
  useEffect(() => {
    tts.stop();
    setPlayState("idle");
    setReading(null);
    load(date, region);
  }, [date, region, load]);

  useEffect(() => () => tts.stop(), []);

  const shift = (days) => setDate((d) => new Date(d.getTime() + days * DAY_MS));
  const isToday = sameDay(date, new Date());
  const year = liturgicalYearLetter(date);
  const weekdayCycle = weekdayCycleNumeral(date);

  const onRegionChange = (e) => {
    const cal = e.target.value;
    setRegion(cal);
    saveRegion(cal);
  };

  const onListen = () => {
    if (state.status !== "ready") return;
    if (playState === "playing") {
      tts.pause();
      setPlayState("paused");
    } else if (playState === "paused") {
      tts.resume();
      setPlayState("playing");
    } else {
      tts.play(state.data.sections, {
        onProgress: (key) => setReading(key),
        onDone: () => {
          setPlayState("idle");
          setReading(null);
        },
      });
      setPlayState("playing");
    }
  };

  const onStop = () => {
    tts.stop();
    setPlayState("idle");
    setReading(null);
  };

  if (!entered) {
    return (
      <EntranceScreen
        dateLabel={displayDate(date)}
        year={year}
        weekdayCycle={weekdayCycle}
        region={region}
        onRegionChange={onRegionChange}
        onEnter={() => setEntered(true)}
      />
    );
  }

  return (
    <div className="page" ref={topRef}>
      <div className="ribbon" aria-hidden="true" />

      <header className="masthead">
        <h1 className="brand">Catholic Daily Mass</h1>
        <p className="brand-sub">The readings at Mass, every day</p>
      </header>

      <div className="meta-row">
        <span className="year-pill">Year {year}</span>
        <span className="year-pill year-pill-secondary">
          Weekday Year {weekdayCycle}
        </span>
      </div>

      <nav className="datenav" aria-label="Choose a date">
        <button className="datenav-btn" onClick={() => shift(-1)} aria-label="Previous day">
          &#8249;
        </button>
        <div className="datenav-center">
          <span className="datenav-date">{displayDate(date)}</span>
          {!isToday && (
            <button className="today-link" onClick={() => setDate(new Date())}>
              Back to today
            </button>
          )}
        </div>
        <button className="datenav-btn" onClick={() => shift(1)} aria-label="Next day">
          &#8250;
        </button>
      </nav>

      <main className="missal">
        {state.status === "loading" && <p className="status">Turning the page&hellip;</p>}

        {state.status === "error" && (
          <div className="status">
            <p>{state.message}</p>
            <button className="retry" onClick={() => load(date, region)}>
              Try again
            </button>
          </div>
        )}

        {state.status === "ready" && (
          <>
            {state.data.day && <h2 className="feast">{state.data.day}</h2>}

            {state.data.sections.map((s) => (
              <section
                key={s.key}
                className={
                  "reading" +
                  (s.key === "Mass_G" ? " gospel" : "") +
                  (reading === s.key ? " being-read" : "")
                }
              >
                <h3 className="reading-label">{s.label}</h3>
                {s.source && (
                  <p className="reading-source" dangerouslySetInnerHTML={{ __html: s.source }} />
                )}
                <div className="reading-text" dangerouslySetInnerHTML={{ __html: s.text }} />
              </section>
            ))}

            {state.data.sections.length === 0 && (
              <p className="status">
                No readings were returned for this day. Try another date, or
                read them directly on Universalis below.
              </p>
            )}
          </>
        )}
      </main>

      <footer className="colophon">
        {state.status === "ready" && state.data.copyright && (
          <div className="copyright" dangerouslySetInnerHTML={{ __html: state.data.copyright }} />
        )}
        <p className="attribution">
          Readings provided by{" "}
          <a href="https://www.universalis.com/mass.htm" target="_blank" rel="noreferrer">
            Universalis
          </a>
          .
        </p>
        <p className="ministry">A free ministry of the Catholic Daily Mass community. &#10013;</p>
      </footer>

      {state.status === "ready" && state.data.sections.length > 0 && tts.isSupported() && (
        <div className="listenbar" role="toolbar" aria-label="Listen">
          <button className="listen-main" onClick={onListen}>
            {playState === "playing" ? "Pause" : playState === "paused" ? "Resume" : "\u25B6 Listen to the readings"}
          </button>
          {playState !== "idle" && (
            <button className="listen-stop" onClick={onStop}>
              Stop
            </button>
          )}
        </div>
      )}
    </div>
  );
}
